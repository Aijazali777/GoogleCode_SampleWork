#pragma once

#include <string>

#include "videolibrary.h"

/**
 * A class used to represent a Video Player.
 */
class VideoPlayer {
 private:
  VideoLibrary mVideoLibrary;

 public:
  VideoPlayer() = default;

  // This class is not copyable to avoid expensive copies.
  VideoPlayer(const VideoPlayer&) = delete;
  VideoPlayer& operator=(const VideoPlayer&) = delete;

  // This class is movable.
  VideoPlayer(VideoPlayer&&) = default;
  VideoPlayer& operator=(VideoPlayer&&) = default;

  void numberOfVideos();
  void showAllVideos();
  void playVideo(const std::string& videoId);
  void stopVideo();
  void playRandomVideo();
  void pauseVideo();
  void continueVideo();
  void showPlaying();
  void createPlaylist(const std::string& playlistName);
  void addVideoToPlaylist(const std::string& playlistName, const std::string& videoId);
  void showAllPlaylists();
  void showPlaylist(const std::string& playlistName);
  void removeFromPlaylist(const std::string& playlistName, const std::string& videoId);
  void clearPlaylist(const std::string& playlistName);
  void deletePlaylist(const std::string& playlistName);
  void searchVideos(const std::string& searchTerm);
  void searchVideosWithTag(const std::string& videoTag);
  void flagVideo(const std::string& videoId);
  void flagVideo(const std::string& videoId, const std::string& reason);
  void allowVideo(const std::string& videoId);
};
  void VideoPlayer::numberOfVideos()
  {
  	int n;
  	int a;
  	cout<<"Enter number of videos in VideoPlayer\n";
  	cin>>n;
  	for(int i=0;i<n;i++)
  	{
  		cout<<"add video\n";
  		cin>>a;
	  }
  }
  void VideoPlayer::showAllVideos()
  {
  	cout<<"Show all videos on screen that are in VideoPlayer\n";
  	int n=100;
  	int i=n;
  	{
  		cout<<" video\n";
  		i++;
	  }while(n==0)
  }
  void VideoPlayer::playVideo(const std::string& videoId)
  {
  	int b;
  	cout<<"Press on play button";
  	cin>>b;
  	cout<<"Play video";
  }
  void VideoPlayer::stopVideo()
  {
  	int b;
  	cout<<"Press on stop button";
  	cin>>b;
  	cout<<"stop video";
  }
  void VideoPlayer::playRandomVideo()
  {
  	
  	cout<<"Press on play button";
  	
  	cout<<"Play  Random video";
  }
  void VideoPlayer::pauseVideo()
  {
  	int b;
  	cout<<"Press on pause button";
  	cin>>b;
  	cout<<"pause video";
  }
  void VideoPlayer::continueVideo()
  {
  	int b;
  	cout<<"Press on continue button";
  	cin>>b;
  	cout<<"continue video";
  }
  void VideoPlayer::showPlaying()
  {
  	
  	cout<<"show video that is  playing ";
  	
  	cout<<"show video";
  }
  void VideoPlayer::createPlaylist(const std::string& playlistName)
  {
  	int n=100;
  	int b[100];
  	cout<<"Please create playlist";
  	for(int i, i<n;i++)
  	{
	  
  	cin>>b[i];
  	
	  }
  	cout<<"PlayList is created";
  }
  void VideoPlayer::addVideoToPlaylist(const std::string& playlistName, const std::string& videoId)
  {
  	int b;
  	cout<<"Press on AddVideo button";
  	cin>>b;
  	cout<<"Add video to PlayList";
  }
  void VideoPlayer::showAllPlaylists()
  {
  	int n=100;
  	int b[100];
  	cout<<"Show all playlist";
  	int i=n;
  	{
	  
  	cin>>b[i];
  	i++
  	
	  }while(i!=0)
  	cout<<"PlayList is shown";
  }
  void VideoPlayer::showPlaylist(const std::string& playlistName)
  {
  	int n=100;
  	int b[100];
  	cout<<"Show all playlist";
  	int i=n;
  	{
	  
  	cin>>b[i];
  	i++
  	
	  }while(i!=0)
  	cout<<"PlayList is shown";
  }
  void VideoPlayer::removeFromPlaylist(const std::string& playlistName, const std::string& videoId)
  {
  	
	int b;
  	cout<<"Press on remove button";
  	cin>>b;
  	cout<<"remove video from PlayList";
  	
  }
  void VideoPlayer::clearPlaylist(const std::string& playlistName)
  {
  	int b;
  	cout<<"Press on clear button";
  	cin>>b;
  	cout<<"to clear  PlayList";
  }
  void VideoPlayer::deletePlaylist(const std::string& playlistName)
  {
  	
  	int b;
  	cout<<"Press on DeleteVideo button";
  	cin>>b;
  	cout<<"Delete video from PlayList";
  }
  void VideoPlayer::searchVideos(const std::string& searchTerm)
  {
  		int n=100;
  	int b[100];
  	cout<<"Search video from playlist";
  	int i=n;
  	{
	  
  	cin>>b[i];
  	i++
  	
	  }while(i!=0)
  	cout<<"video found";
  }
  void VideoPlayer::searchVideosWithTag(const std::string& videoTag)
  {
  	int n=100;
  	int b[100];
  	cout<<"Search a video from playlist";
  	int i=n;
  	{
	  
  	cin>>b[i];
  	i++
  	
	  }while(i!=0)
  	cout<<"video found with Tag";
  }
  void VideoPlayer::flagVideo(const std::string& videoId)
  {
  	bool b;
  	cout<<"Flag the video";
  	cin>>b;
  	
  	cout<<"Video is flaged";
  }
  void VideoPlayer::flagVideo(const std::string& videoId, const std::string& reason)
  {
  	bool b;
  	cout<<"bool video";
  	cin>>b;
  	cout<<"video is flaged";
  }
  void VideoPlayer::allowVideo(const std::string& videoId)
  {
  	int b;
  	cout<<"Press on allow button";
  	cin>>b;
  	cout<<"to allow video";
  }
