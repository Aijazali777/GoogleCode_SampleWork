#include "videoplaylist.h"

#include <string>
#include <unordered_map>
#include <vector>

#include "video.h"

/**
 * A class used to represent a Video Library.
 */
class VideoLibrary {
 private:
  std::unordered_map<std::string, Video> mVideos;

 public:
  VideoLibrary();

  // This class is not copyable to avoid expensive copies.
  VideoLibrary(const VideoLibrary&) = delete;
  VideoLibrary& operator=(const VideoLibrary&) = delete;

  // This class is movable.
  VideoLibrary(VideoLibrary&&) = default;
  VideoLibrary& operator=(VideoLibrary&&) = default;

  std::vector<Video> getVideos() const;
  const Video *getVideo(const std::string& videoId) const;
};

VideoCapture cap("Bumpy.mp4");
    // cap is the object of class video capture that tries to capture Bumpy.mp4
    if ( !cap.isOpened() )  // isOpened() returns true if capturing has been initialized.
    {
        cout << "Cannot open the video file. \n";
        return -1;
    }

    double fps = cap.get(CV_CAP_PROP_FPS); //get the frames per seconds of the video
    // The function get is used to derive a property from the element.
   

    namedWindow("A_good_name",CV_WINDOW_AUTOSIZE); //create a window called "MyVideo"
    

    while(1)
    {
        Mat frame;

        if (!cap.read(frame)) // if not success, break loop
        // read() decodes and captures the next frame.
        {
            cout<<"\n Cannot read the video file. \n";
            break;
        }

        imshow("A_good_name", frame);
       

        if(waitKey(30) == 27) // Wait for 'esc' key press to exit
        { 
            break; 
        }
    }

    return 0;
}
// END OF PROGRAM
::ShowWindow(m_Video,SW_MAXIMIZE);

m_SVolume.SetRange( 0, 1000, TRUE );  // Set Slider range
m_SVolume.SetPos(500);   // Set volume Position initially 
m_mute.SetCheck(1);  // Set Checked the Volume check box 
ptr=FromHandle(m_Video);   // Get handler of Window created 
ptr->UpdateWindow();

MCIWndSetTimeFormat(m_Video ,"ms");   // Set time Format 
m_length=MCIWndGetLength(m_Video );   // Get Video Length
TotalTime=m_length/1000;
TotalTime=TotalTime/100;
m_Seek.SetRange( 0, m_length, TRUE );   // Set Seek slider bar range
m_Seek.SetPos(0);
MCIWndPlay(m_Video);   // Play the File
flag=1;

}

//We can play a song  by double clicking on  File name

i=m_control.GetCurSel();
m_control.GetText(i,str);

if(((CMP3Dlg*)GetParent())->m_Video!=NULL)
{
MCIWndStop(((CMP3Dlg*)GetParent())->m_Video);
MCIWndDestroy(((CMP3Dlg*)GetParent())->m_Video);
((CMP3Dlg*)GetParent())->m_Video=NULL;
((CMP3Dlg*)GetParent())->m_Path=((CMP3Dlg*)GetParent())->OldFileName2; 
}
((CMP3Dlg*)GetParent())->NewFileName2=st;
((CMP3Dlg*)GetParent())->OldFilename=st;
((CMP3Dlg*)GetParent())->flag=0;
((CMP3Dlg*)GetParent())->CreateWindowplay(str);

}

